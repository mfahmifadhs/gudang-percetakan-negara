<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="text-capitalize">daftar <?php echo e($id); ?> barang</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right text-capitalize">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">daftar <?php echo e($id); ?> barang</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<!-- Content Header -->

<section class="content">
    <div class="container-fluid">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title">Barang Masuk</h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <table id="table-1" class="table table-bordered">
                    <thead class="text-center">
                        <tr>
                            <th>No</th>
                            <th>Unit Kerja</th>
                            <th>Pengirim / Jabatan</th>
                            <th>Jam / Tanggal</th>
                            <th>Total Barang</th>
                            <th></th>
                        </tr>
                    </thead>
                    <?php $no = 1; ?>
                    <tbody class="text-capitalize text-center">
                        <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?> </td>
                            <td><?php echo e($activity->workunit_name); ?> </td>
                            <td><?php echo e($activity->order_emp_name.' / '.$activity->order_emp_position); ?> </td>
                            <td><?php echo e($activity->order_tm .' / '.\Carbon\Carbon::parse($activity->order_dt)->isoFormat('DD MMMM Y')); ?></td>
                            <td><?php echo e($activity->order_total_item); ?> barang</td>
                            <td class="text-center">
                                <a type="button" class="btn btn-primary" data-toggle="dropdown">
                                    <i class="fas fa-bars"></i>
                                </a>
                                <div class="dropdown-menu">
                                    <?php if($activity->order_category == 'penyimpanan'): ?>
                                    <a class="dropdown-item btn" href="<?php echo e(url('petugas/print-qrcode/'. $activity->id_order)); ?>" target="_blank">
                                        <i class="fas fa-qrcode"></i> Cetak QR Code
                                    </a>
                                    <?php endif; ?>
                                    <a class="dropdown-item btn" rel="noopener" target="_blank" href="<?php echo e(url('petugas/buat-bast/'.$activity->id_order)); ?>">
                                        <i class="fas fa-file"></i> BAST
                                    </a>
                                    <a class="dropdown-item btn" href="<?php echo e(url('petugas/barang/cari/'. $activity->id_order)); ?>">
                                        <i class="fas fa-info-circle"></i> Detail
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table-1").DataTable({
            "responsive": true,
            "lengthChange": true,
            "autoWidth": true,
            "searching": false,
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/show_activity.blade.php ENDPATH**/ ?>