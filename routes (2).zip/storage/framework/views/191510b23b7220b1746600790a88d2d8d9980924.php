<?php $__env->startSection('content'); ?>

<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"><?php echo e($slot->warehouse_name); ?></h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/gudang/daftar/semua')); ?>">Daftar Gudang</a></li>
          <li class="breadcrumb-item active"><?php echo e($slot->warehouse_name); ?></li>
        </ol>
      </div>
    </div>
  </div>
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 form-group">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
          <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
        </div>
        <?php elseif($message = Session::get('failed')): ?>
        <div class="alert alert-danger">
          <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
      </div>
      <div class="col-md-12 form-group">
        <div class="card card-primary card-tabs">
          <div class="card-header p-0 pt-1">
            <ul class="nav nav-tabs" id="custom-tabs-two-tab" role="tablist">
              <li class="pt-2 px-3"><h3 class="card-title">MASTER BARANG</h3></li>
              <li class="nav-item">
                <a class="nav-link active" id="tabs-incoming-tab" data-toggle="pill" href="#tabs-incoming" role="tab"
              aria-controls="tabs-incoming" aria-selected="false">Barang Masuk</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="tabs-pickup-tab" data-toggle="pill" href="#tabs-pickup" role="tab"
                aria-controls="tabs-pickup" aria-selected="false">Barang Keluar</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="tabs-category-tab" data-toggle="pill" href="#tabs-category" role="tab"
                aria-controls="tabs-category" aria-selected="false">Kategori Barang</a>
              </li>
            </ul>
          </div>
          <div class="card-body">
            <div class="tab-content" id="custom-tabs-two-tabContent">
              <div class="tab-pane fade show active" id="tabs-incoming" role="tabpanel" aria-labelledby="tabs-incoming-tab">
                <table id="table-incoming" class="table table-bordered table-responsive text-center">
                  <thead>
                    <tr>
                      <th style="width: 12%;">Kode Barang</th>
                      <th style="width: 8%;">NUP</th>
                      <th style="width: 10%;">Jenis</th>
                      <th>Nama Barang</th>
                      <th style="width: 10%;">Jumlah</th>
                      <th style="width: 10%;">Lok. Penyimpanan</th>
                      <th style="width: 20%;">Unit Kerja</th>
                      <th style="width: 15%;">Tanggal Masuk</th>
                    </tr>
                  </thead>
                  <?php $no = 1;?>
                  <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <?php if($dataItem->item_code == null): ?>
                      <td>-</td>
                      <?php else: ?>
                      <td><?php echo e($dataItem->item_code); ?></td>
                      <?php endif; ?>
                      <?php if($dataItem->item_code == null): ?>
                      <td>-</td>
                      <?php else: ?>
                      <td><?php echo e($dataItem->in_item_nup); ?></td>
                      <?php endif; ?>
                      <td><?php echo e($dataItem->item_category_name); ?></td>
                      <td><?php echo e($dataItem->item_name); ?></td>
                      <td><?php echo e($dataItem->total_item.' '.$dataItem->item_unit); ?></td>
                      <td><?php echo e($dataItem->slot_id); ?></td>
                      <td><?php echo e($dataItem->workunit_name); ?></td>
                      <td><?php echo e(\Carbon\Carbon::parse($dataItem->order_dt)->isoFormat('DD MMMM Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade" id="tabs-pickup" role="tabpanel" aria-labelledby="tabs-pickup-tab">
                <table id="table-pickup" class="table table-bordered table-responsive text-center">
                  <thead>
                    <tr>
                      <th style="width: 12%;">Kode Barang</th>
                      <th style="width: 8%;">NUP</th>
                      <th style="width: 10%;">Jenis</th>
                      <th>Nama Barang</th>
                      <th style="width: 10%;">Jumlah</th>
                      <th style="width: 10%;">Lok. Penyimpanan</th>
                      <th style="width: 20%;">Unit Kerja</th>
                      <th style="width: 15%;">Tanggal Masuk</th>
                    </tr>
                  </thead>
                  <?php $no = 1;?>
                  <tbody>
                    <?php $__currentLoopData = $itemExit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataItemExit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <?php if($dataItemExit->item_code == null): ?>
                      <td>-</td>
                      <?php else: ?>
                      <td><?php echo e($dataItemExit->item_code); ?></td>
                      <?php endif; ?>
                      <?php if($dataItemExit->item_code == null): ?>
                      <td>-</td>
                      <?php else: ?>
                      <td><?php echo e($dataItemExit->item_nup); ?></td>
                      <?php endif; ?>
                      <td><?php echo e($dataItemExit->item_category_name); ?></td>
                      <td><?php echo e($dataItemExit->item_name); ?></td>
                      <td><?php echo e($dataItemExit->total_item.' '.$dataItemExit->item_unit); ?></td>
                      <td><?php echo e($dataItemExit->slot_id); ?></td>
                      <td><?php echo e($dataItemExit->workunit_name); ?></td>
                      <td><?php echo e(\Carbon\Carbon::parse($dataItemExit->order_dt)->isoFormat('DD MMMM Y')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane fade" id="tabs-category" role="tabpanel" aria-labelledby="tabs-category-tab">
                <table id="table-category" class="table table-bordered table-responsive text-center">
                  <thead>
                    <tr>
                    <th style="width: 1%;">No</th>
                    <th style="width: 39%;">Jenis Barang</th>
                    <th>Keterangan</th>
                    </tr>
                  </thead>
                  <?php $no = 1;?>
                  <?php $__currentLoopData = $itemCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tbody>
                    <tr>
                      <td><?php echo e($no++); ?></td>
                      <td><?php echo e($category->item_category_name); ?></td>
                      <td><?php echo e($category->item_category_description); ?></td>
                    </tr>
                  </tbody>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
  $(function () {
    $("#table-incoming").DataTable({
      "responsive": true, "lengthChange": true  , "autoWidth": false ,
      "buttons": ["excel", "pdf", "print"]
    }).buttons().container().appendTo('#table-incoming_wrapper .col-md-6:eq(0)');

    $("#table-pickup").DataTable({
      "responsive": true, "lengthChange": true  , "autoWidth": false ,
      "buttons": ["excel", "pdf", "print"]
    }).buttons().container().appendTo('#table-pickup_wrapper .col-md-6:eq(0)');

    $("#table-category").DataTable({
      "responsive": true, "lengthChange": true  , "autoWidth": false ,
      "buttons": ["excel", "pdf", "print"]
    }).buttons().container().appendTo('#table-category_wrapper .col-md-6:eq(0)');
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/detail_slot.blade.php ENDPATH**/ ?>