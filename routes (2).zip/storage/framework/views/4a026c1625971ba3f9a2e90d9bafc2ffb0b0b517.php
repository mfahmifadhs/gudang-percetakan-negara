<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="text-capitalize">
                    daftar barang masuk
                </h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right text-capitalize">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/aktivitas/daftar/pengiriman')); ?>">Daftar Pengiriman</a></li>
                    <li class="breadcrumb-item active">daftar barang masuk</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<!-- Content Header -->

<section class="content">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-12 form-group">
                <div class="row">
                    <div class="col-md-12 form-group">
                        <div class="card card-outline card-primary">
                            <div class="card-body">
                                <table id="table1" class="table table-bordered">
                                    <thead class="text-center">
                                        <tr>
                                            <th>No</th>
                                            <th>Unit Kerja</thstyle=>
                                            <th>Nama Barang</th>
                                            <th>Keterangan</th>
                                            <th>Jumlah</th>
                                            <th>Satuan</th>
                                            <th>Kondisi</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <?php $no = 1; ?>
                                    <tbody class="text-capitalize text-center">
                                        <?php $__currentLoopData = $itemEntry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($dataItem->workunit_name); ?></td>
                                            <td><?php echo e($dataItem->item_name); ?></td>
                                            <td><?php echo e($dataItem->item_description); ?></td>
                                            <td><?php echo e($dataItem->item_qty); ?></td>
                                            <td><?php echo e($dataItem->item_unit); ?></td>
                                            <td><?php echo e($dataItem->item_condition_name); ?></td>
                                            <td class="text-center">
                                                <a type="button" class="btn btn-primary" data-toggle="dropdown">
                                                    <i class="fas fa-bars"></i>
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item btn" href="<?php echo e(url('petugas/barang/detail/'. $dataItem->id_item)); ?>" >
                                                        <i class="fas fa-info-circle"></i> Detail
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table1").DataTable({
            "responsive": true,
            "lengthChange": true,
            "autoWidth": true
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/show_item_entry.blade.php ENDPATH**/ ?>