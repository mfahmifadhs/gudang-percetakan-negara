<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Daftar Pengiriman Barang</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Daftar Pengiriman Barang</li>
        </ol>
      </div>
    </div>
  </div>
</section>
<!-- Content Header -->

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
          <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('failed')): ?>
        <div class="alert alert-danger">
          <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
      </div>
      <div class="col-md-12">
        <div class="row">
          <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 form-group">
            <div class="card" style="height: 100%;font-size: 14px;">
              <div class="card-header">
                <h3 class="card-title mt-2 font-weight-bold"><?php echo e($warehouse->warehouse_name); ?></h3>
                <div class="card-tools">
                  <a href="<?php echo e(url('petugas/gudang/detail/'.$warehouse->id_warehouse)); ?>" class="btn btn-default"
                  title="Cek Gudang">
                    <i class="fas fa-pallet"></i>
                  </a>
                </div>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6 form-group text-center">
                    <img src="https://cdn-icons-png.flaticon.com/512/2271/2271068.png" style="height: 30vh;"
                    class="img-thumbnail">
                  </div>
                  <div class="col-md-6">
                    <div class="row">
                      <div class="col-md-6">
                        <label>Kode</label>
                        <p><?php echo e($warehouse->id_warehouse); ?></p>
                      </div>
                      <div class="col-md-6">
                        <label>Model Penyimpanan</label>
                        <p><?php echo e($warehouse->warehouse_category); ?></p>
                      </div>
                      <div class="col-md-6">
                        <label>Nama Gudang</label>
                        <p><?php echo e($warehouse->warehouse_name); ?></p>
                      </div>
                      <div class="col-md-6">
                        <label>Status</label>
                        <?php if($warehouse->status_id == 1): ?>
                        <p class="text-success font-weight-bold" readonly>Aktif</p>
                        <?php elseif($warehouse->status_id == 2): ?>
                        <p class="text-danger font-weight-bold" readonly>Tidak Aktif</p>
                        <?php endif; ?>
                      </div>
                      <div class="col-md-12">
                        <label>Keterangan</label>
                        <p><?php echo $warehouse->warehouse_description; ?></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($warehouses->links("pagination::bootstrap-4")); ?>

        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/show_warehouse.blade.php ENDPATH**/ ?>