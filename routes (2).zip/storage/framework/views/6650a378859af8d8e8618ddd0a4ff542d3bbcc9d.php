<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Pengeluaran Barang</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Pengeluaran Barang</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<!-- Content Header -->

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 form-group">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
                </div>
                <?php elseif($message = Session::get('failed')): ?>
                <div class="alert alert-danger">
                    <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-12 form-group">
                <form action="<?php echo e(url('petugas/barang/proses-ambil/'. $order->id_order)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="warrent_id" value="<?php echo e($id); ?>">
                    <div class="card card-outline card-body">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-md-3">
                                    <label>Jumlah Barang</label>
                                    <div class="form-group">
                                        <input type="text" value="<?php echo e($order->order_total_item.' barang'); ?>" class="form-control" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <table id="table-1" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Barang</th>
                                        <th>Penyimpanan</th>
                                        <th>Jumlah Pengambilan</th>
                                        <th>Sisa Stok Barang</th>
                                    </tr>
                                </thead>
                                <?php $no = 1; ?>
                                <tbody id="input-item-entry">
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $dataItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="hidden" name="idData[<?php echo e($i); ?>]" value="<?php echo e('DATA_'.\Carbon\Carbon::now()->format('dmy').rand(100,999).$i); ?>">
                                            <input type="hidden" name="slot_id[]" value="<?php echo e($dataItem->slot_id); ?>">
                                            <input type="hidden" name="item_id[]" value="<?php echo e($dataItem->item_id); ?>">
                                            <input type="hidden" name="item_pick[]" value="<?php echo e($dataItem->warr_item_pick); ?>">
                                            <?php echo e($no++); ?>

                                        </td>
                                        <td><?php echo e($dataItem->item_name); ?></td>
                                        <td><?php echo e($dataItem->slot_id.' / '.$dataItem->warehouse_name); ?></td>
                                        <td><?php echo e($dataItem->warr_item_pick.' '.$dataItem->item_unit); ?></td>
                                        <td>
                                            <input type="hidden" name="item_stock[]" value="<?php echo e($dataItem->total_item - $dataItem->warr_item_pick); ?>">
                                            <?php echo e($dataItem->total_item - $dataItem->warr_item_pick.' '.$dataItem->item_unit); ?>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot></tfoot>
                            </table>
                            <button type="submit" class="btn btn-primary mt-2" onclick="return confirm('Apakah pengambilan barang sudah benar ?')">Submit</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table-1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "paging": false,
            "info": false,
            "ordering": false,
            "searching": false
        })
    })
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/create_pickup.blade.php ENDPATH**/ ?>