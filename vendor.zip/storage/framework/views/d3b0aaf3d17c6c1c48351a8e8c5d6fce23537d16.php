<?php $__env->startSection('content'); ?>

  <!-- About Start -->
  <div class="container-xxl py-5">
    <div class="container" style="margin-top: 150px;">
      <div class="row g-5">
        <div class="col-lg-10 wow fadeInUp" data-wow-delay="0.5s">
          <div class="h-100">
            <div class="d-inline-block rounded-pill bg-secondary text-primary py-1 px-3 mb-3">#GudangPercetakanNegara</div>
            <h1 class="display-6 mb-5">Surat Permohonan Pengajuan</h1>
            <table id="table1" class="table table-bordered table-striped text-capitalize text-center">
              <thead style="color: black;">
                <tr>
                  <th>No</th>
                  <th>Tanggal</th>
                  <th>Unit Kerja</th>
                  <th>Tujuan</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <?php $no = 1;?>
              <tbody>
                <?php $__currentLoopData = $appletter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataAppletter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($dataAppletter->appletter_date)->isoFormat('HH:mm / DD MMMM Y')); ?></td>
                  <td><?php echo e($dataAppletter->workunit_name); ?></td>
                  <td><?php echo e($dataAppletter->appletter_purpose); ?> barang</td>
                  <td><?php echo e($dataAppletter->appletter_status); ?></td>
                  <td>
                    <div class="dropdown">
                      <a href="#" class="dropdown-toggle btn btn-primary" data-bs-toggle="dropdown">
                        <i class="fas fa-bars"></i>
                      </a>
                      <div class="dropdown-menu m-0">
                        <a class="dropdown-item" href="<?php echo e(url('tim-kerja/surat/detail-surat-pengajuan/'. $dataAppletter->id_app_letter)); ?>">
                          <i class="fas fa-info-circle"></i> Detail
                        </a>
                      </div>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->startSection('js'); ?>
<script>
  $(function () {
    $("#table1").DataTable({
      "responsive": true, "lengthChange": false  , "autoWidth": false,
      "searching": false, "info": false, "sort": false, "paging": false
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_main.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_workteam/index.blade.php ENDPATH**/ ?>