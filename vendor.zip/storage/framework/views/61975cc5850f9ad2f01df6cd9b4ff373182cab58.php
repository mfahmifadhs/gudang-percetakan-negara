<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Penapisan Barang <small>(<?php echo e(\Carbon\Carbon::parse($warrent->warr_date)->isoFormat('DD MMMM Y')); ?>)</small></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('petugas/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Penapisan Barang</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<!-- Content Header -->

<section class="content">
    <div class="container-fluid">
        <div class="col-md-12 form-group">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
            </div>
            <?php elseif($message = Session::get('failed')): ?>
            <div class="alert alert-danger">
                <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(url('petugas/surat-perintah/proses-penapisan/'. $warrent->id_warrent)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="total_item" value="<?php echo e($warrent->warr_total_item); ?>">
            <div class="row">
                <div class="col-md-3 form-group">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold  ">Informasi Pengirim</h3>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <label>Surat Perintah</label>
                                    <p><a href="<?php echo e(asset('data_file/surat_perintah/'. $warrent->warr_file)); ?>" download><?php echo e($warrent->warr_file); ?></a></p>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Unit Kerja</label>
                                    <input type="hidden" class="form-control" name="workunit_id" value="<?php echo e($warrent->workunit_id); ?>">
                                    <input type="text" class="form-control" value="<?php echo e($warrent->workunit_name); ?>" readonly>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Tujuan</label>
                                    <input type="text" class="form-control text-capitalize" name="category" value="<?php echo e($warrent->warr_purpose); ?>" readonly>
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Pengirim</label>
                                    <input type="text" class="form-control" name="emp_name" value="<?php echo e($warrent->warr_emp_name); ?>">
                                </div>
                                <div class="col-md-6 form-group">
                                    <label>Jabatan</label>
                                    <input type="text" class="form-control" name="emp_position" value="<?php echo e($warrent->warr_emp_position); ?>">
                                </div>
                                <div class="col-md-12 form-group">
                                    <label>No. Mobil</label>
                                    <input type="text" class="form-control" name="license_vehicle" placeholder="Masukan Nomor Mobil Pengirim" required>
                                </div>
                                <div class="col-md-12 form-group">
                                    <button type="submit" class="btn btn-primary" onclick="return confirm('Data yang telah tersimpan, tidak dapat diubah. Proses penapisan selesai ?')">Submit</button>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-md-9 form-group">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold">Informasi Barang</h3>
                        </div>
                        <div class="card-body">
                            <?php if($warrent->warr_purpose == 'penyimpanan'): ?>
                            <table id="table-1" class="table table-bordered">
                                <thead class="text-center">
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Merk/Type</th;>
                                        <th>Jumlah <br>(pengajuan)</th>
                                        <th>Jumlah <br>(diterima)</th>
                                        <th>Satuan</th>
                                        <th>Status</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <?php $no = 1; ?>
                                <tbody>
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="hidden" name="item_id[]" value="<?php echo e($itemEntry->id_warr_entry); ?>">
                                            <?php echo e($no++); ?>

                                        </td>
                                        <td><?php echo e($itemEntry->warr_item_name); ?></td>
                                        <td><?php echo e($itemEntry->warr_item_description); ?></td>
                                        <td class="text-center"><?php echo e($itemEntry->warr_item_qty); ?></td>
                                        <td class="text-center">
                                            <input type="text" class="form-control" name="item_received[]" placeholder="Jumlah diterima" required>
                                        </td>
                                        <td class="text-center"><?php echo e($itemEntry->warr_item_unit); ?></td>
                                        <td>
                                            <select name="status_screening[]" class="form-control">
                                                <option value="sesuai">sesuai</option>
                                                <option value="tidak sesuai">tidak sesuai</option>
                                            </select>
                                        </td>
                                        <td>
                                            <textarea name="screening_notes[]" class="form-control" cols="30" rows="2"></textarea>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                            <table id="table-1" class="table table-bordered">
                                <thead class="text-center">
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Merk/Type</th;>
                                        <th>Jumlah <br>(pengajuan)</th>
                                        <th>Jumlah <br>(diambil)</th>
                                        <th>Satuan</th>
                                        <th>Status</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <?php $no = 1; ?>
                                <tbody>
                                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemExit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="hidden" name="item_id[]" value="<?php echo e($itemExit->item_id); ?>">
                                            <?php echo e($no++); ?>

                                        </td>
                                        <td><?php echo e($itemExit->in_item_name); ?></td>
                                        <td><?php echo e($itemExit->in_item_merk); ?></td>
                                        <td class="text-center"><?php echo e($itemExit->warr_item_pick); ?></td>
                                        <td class="text-center">
                                            <input type="text" class="form-control" name="item_received[]" placeholder="Jumlah diambil" required>
                                        </td>
                                        <td class="text-center"><?php echo e($itemExit->in_item_unit); ?></td>
                                        <td>
                                            <select name="status_screening[]" class="form-control">
                                                <option value="sesuai">sesuai</option>
                                                <option value="tidak sesuai">tidak sesuai</option>
                                            </select>
                                        </td>
                                        <td>
                                            <textarea name="order_note" class="form-control" cols="30" rows="2"></textarea>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table-1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "paging": false, "info": false,"ordering": false, "searching": false
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/screening_item.blade.php ENDPATH**/ ?>