<?php $__env->startSection('content'); ?>

<div class="container-xxl py-5">
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-md-3 form-group">
                <div class="row">
                    <div class="col-md-12 mb-2">
                        <h6 class="text-capitalize">tanggal <?php echo e($warrent->warr_purpose); ?> : </h6>
                        <p class="mt-2">
                            <?php echo e(\Carbon\Carbon::parse($warrent->warr_date)->isoFormat('DD MMMM Y')); ?>

                        </p>
                    </div>
                    <div class="col-md-12 mb-2">
                        <h6 class="text-capitalize">surat perintah <?php echo e($warrent->warr_purpose); ?> :</h6>
                        <p class="mt-2">
                            <a href="<?php echo e(asset('data_file/surat_permohonan/'. $warrent->warr_file)); ?>" target="_blank"><?php echo e($warrent->warr_file); ?></a>
                        </p>
                    </div>
                    <div class="col-md-12 mb-2">
                        <h6 class="text-capitalize">status <?php echo e($warrent->warr_purpose); ?> :</h6>
                        <p class="mt-2">
                            <?php if($warrent->warr_status == 'proses'): ?>
                            <a class="btn btn-outline-primary py-2 px-3 disabled">
                                Diproses
                            </a>
                            <?php elseif($warrent->warr_status == 'konfirmasi'): ?>
                            <a class="btn btn-outline-danger py-2 px-3 disabled">
                                Menunggu Konfirmasi
                            </a>
                            <?php else: ?>
                            <a class="btn btn-outline-success py-2 px-3 disabled">
                                Selesai
                            </a>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-9 form-group">
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <a href="<?php echo e(url('unit-kerja/surat/daftar-surat-pengajuan/semua')); ?>" class=""><i class="fas fa-arrow-alt-circle-left"></i> KEMBALI</a>
                    </div>

                    <?php if($warrent->warr_status == 'konfirmasi'): ?>
                    <form action="<?php echo e(url('unit-kerja/surat-perintah/konfirmasi-penapisan/'. $warrent->id_warrent)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="card-title pt-2">Daftar Barang</h6>
                                </div>
                                <div class="card-body">
                                    <?php if($warrent->warr_purpose == 'penyimpanan'): ?>
                                    <table id="table-1" class="table table-bordered">
                                        <thead class="text-center">
                                            <tr>
                                                <th>No</th>
                                                <th>Nama</th>
                                                <th>Jumlah <br>(pengajuan)</th>
                                                <th>Jumlah <br>(diterima)</th>
                                                <th>Status</th>
                                                <th>Konfirmasi</th>
                                                <th>Keterangan</th>
                                            </tr>
                                        </thead>
                                        <?php $no = 1; ?>
                                        <tbody>
                                            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input type="hidden" name="id_screening[]" value="<?php echo e($itemEntry->id_item_screening); ?>">
                                                    <?php echo e($no++); ?>

                                                </td>
                                                <td><?php echo e($itemEntry->warr_item_name.' '.$itemEntry->warr_item_description); ?></td>
                                                <td class="text-center"><?php echo e($itemEntry->warr_item_qty.' '.$itemEntry->warr_item_unit); ?></td>
                                                <td class="text-center"><?php echo e($itemEntry->item_received.' '.$itemEntry->warr_item_unit); ?></td>
                                                <td class="text-center">
                                                    <?php if($itemEntry->status_screening == 'sesuai'): ?>
                                                    <b>sesuai</b>
                                                    <?php else: ?>
                                                    <b>tidak sesuai</b> <br>
                                                    <small>(<?php echo e($itemEntry->screening_notes); ?>)</small>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <select name="approve_workunit[]" class="form-control bg-white text-center">
                                                        <option value="1">setuju</option>
                                                        <option value="0">tidak setuju</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <textarea name="screening_notes_workunit[]" rows="1" class="form-control" placeholder=""></textarea>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php else: ?>
                                    <table id="table-1" class="table table-bordered">
                                        <thead class="text-center">
                                            <tr>
                                                <th>No</th>
                                                <th>Nama</th>
                                                <th>Jumlah <br>(pengajuan)</th>
                                                <th>Jumlah <br>(diambil)</th>
                                                <th>Status</th>
                                                <th>Konfirmasi</th>
                                                <th>Keterangan</th>
                                            </tr>
                                        </thead>
                                        <?php $no = 1; ?>
                                        <tbody>
                                            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemExit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <input type="hidden" name="id_screening[]" value="<?php echo e($itemExit->id_item_screening); ?>">
                                                    <?php echo e($no++); ?>

                                                </td>
                                                <td><?php echo e($itemExit->in_item_name.' '.$itemExit->in_item_merk); ?></td>
                                                <td class="text-center"><?php echo e($itemExit->warr_item_pick.' '.$itemExit->in_item_unit); ?></td>
                                                <td class="text-center"><?php echo e($itemExit->item_received.' '.$itemExit->in_item_unit); ?></td>
                                                <td class="text-center">
                                                    <?php if($itemExit->status_screening == 'sesuai'): ?>
                                                    <b>sesuai</b>
                                                    <?php else: ?>
                                                    <b>tidak sesuai</b>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <select name="approve_workunit[]" class="form-control bg-white text-center">
                                                        <option value="1">setuju</option>
                                                        <option value="0">tidak setuju</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <textarea name="screening_notes_workunit[]" rows="1" class="form-control" placeholder=""></textarea>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary mt-2" onclick="return confirm('Apakah setuju dengan konfirmasi yang telah diberikan ?')">SUBMIT</button>
                        </div>
                    </form>
                    <?php else: ?>
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="card-title pt-2">Daftar Barang</h6>
                            </div>
                            <div class="card-body">
                                <?php if($warrent->warr_purpose == 'penyimpanan'): ?>
                                <table id="table-1" class="table table-bordered">
                                    <thead class="text-center">
                                        <tr>
                                            <th>No</th>
                                            <th>Jenis Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Merk/Tipe</th>
                                            <th>Jumlah</th>
                                            <th>Satuan</th>
                                            <th>Kondisi</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <?php $no = 1; ?>
                                    <tbody>
                                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($itemEntry->item_category_name); ?></td>
                                            <td><?php echo e($itemEntry->warr_item_name); ?></td>
                                            <td><?php echo e($itemEntry->warr_item_description); ?></td>
                                            <td><?php echo e($itemEntry->warr_item_qty); ?></td>
                                            <td><?php echo e($itemEntry->warr_item_unit); ?></td>
                                            <td><?php echo e($itemEntry->item_condition_name); ?></td>
                                            <td><?php echo e($itemEntry->warr_item_status); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                <table id="table-1" class="table table-bordered">
                                    <thead class="text-center">
                                        <tr>
                                            <th>No</th>
                                            <th>Jenis Barang</th>
                                            <th>Nama Barang</th>
                                            <th>Merk/Tipe</th>
                                            <th>Jumlah</th>
                                            <th>Satuan</th>
                                            <th>Kondisi</th>
                                        </tr>
                                    </thead>
                                    <?php $no = 1; ?>
                                    <tbody>
                                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemExit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($itemExit->item_category_name); ?></td>
                                            <td><?php echo e($itemExit->in_item_name); ?></td>
                                            <td><?php echo e($itemExit->in_item_merk); ?></td>
                                            <td><?php echo e($itemExit->warr_item_pick); ?></td>
                                            <td><?php echo e($itemExit->in_item_unit); ?></td>
                                            <td><?php echo e($itemExit->item_condition_name); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table-1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "info": false,
            "sort": false,
            "paging": false,
            "searching": false
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_main.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_workunit/detail_surat_perintah.blade.php ENDPATH**/ ?>