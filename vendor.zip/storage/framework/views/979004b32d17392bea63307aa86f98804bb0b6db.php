<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0"><b><?php echo e($users->full_name .' - '. $users->workunit_name); ?></b></h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin-master/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin-master/pengguna/daftar/semua')); ?>">Daftar Pengguna</a></li>
          <li class="breadcrumb-item active"><?php echo e($users->full_name); ?></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3">
        <!-- Profile Image -->
        <div class="card card-primary card-outline">
          <div class="card-body box-profile">
            <div class="text-center">
              <img class="profile-user-img img-fluid img-circle" src="https://cdn-icons-png.flaticon.com/512/599/599305.png" alt="Profil">
            </div>
            <h3 class="profile-username text-center"><?php echo e($users->full_name); ?></h3>
            <p class="text-muted text-center"><?php echo e($users->workunit_name); ?></p>
          </div>
        </div>
      </div>
      <div class="col-md-9">
        <div class="card">
          <div class="card-header p-2">
            <ul class="nav nav-pills">
              <li class="nav-item"><a class="nav-link active" href="#profil" data-toggle="tab">Profil</a></li>
            </ul>
          </div><!-- /.card-header -->
          <div class="card-body">
            <div class="tab-content">
              <div class="active tab-pane" id="profil">
                <form class="form-horizontal" action="<?php echo e(url('admin-master/pengguna/ubah/'. $users->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Unit Kerja</label>
                    <div class="col-sm-4">
                      <select id="select2-workunit" name="workunit_id" class="form-control select2-workunit">
                        <option value="<?php echo e($users->workunit_id); ?>"><?php echo e($users->workunit_name); ?></option>
                      </select>
                    </div>
                    <label class="col-sm-2 col-form-label">Unit Utama</label>
                    <div class="col-sm-4">
                      <select id="mainunit" class="form-control" readonly>
                        <option value=""><?php echo e($users->mainunit_name); ?></option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Nama</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="full_name" value="<?php echo e($users->full_name); ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-2 col-form-label">NIP</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="nip" value="<?php echo e($users->nip); ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-sm-2 col-form-label">Password</label>
                    <div class="col-sm-10">
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text">
                            <a type="button" onclick="viewPass()"><i class="fas fa-eye"></i></a>
                          </span>
                        </div>
                        <input type="password" id="password" name="password" class="form-control" value="<?php echo e($users->password_text); ?>">
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputName2" class="col-sm-2 col-form-label">Role</label>
                    <div class="col-sm-10">
                      <select class="form-control" name="role_id">
                      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id_role); ?>"
                          <?php if($users->role_id == $role->id_role) echo "selected"; ?>>
                          <?php echo e($role->role_name); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputName2" class="col-sm-2 col-form-label">Status</label>
                    <div class="col-sm-10">
                      <select class="form-control" name="status_id">
                      <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status->id_status); ?>"
                          <?php if($users->status_id == $status->id_status) echo "selected"; ?>>
                          <?php echo e($status->status_name); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="offset-sm-2 col-sm-10">
                      <button type="submit" class="btn btn-primary" onclick="return confirm('Data sudah benar ?')">Ubah</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- /.content -->

<?php $__env->startSection('js'); ?>
<script>
  function viewPass() {
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }
  $(function () {
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    $( "#select2-workunit" ).select2({
      ajax: {
        url: "<?php echo e(url('admin-master/select2/workunit/daftar')); ?>",
        type: "post",
        dataType: 'json',
        delay: 250,
        data: function (params) {
          return {
            _token: CSRF_TOKEN,
            search: params.term // search term
          };
        },
        processResults: function (response) {
          return {
            results: response
          };
        },
        cache: true
      }
    });

    $('.select2-workunit').change(function(){
      var workunit = $(this).val();
      console.log(workunit);
      if(workunit){
          $.ajax({
              type:"GET",
              url:"/admin-master/json/mainunit/" + workunit,
              dataType: 'JSON',
              success:function(res){
              if(res){
                  $("#mainunit").empty();
                  $.each(res,function(mainunit_name,id_mainunit){
                      $("#mainunit").append(
                        '<option value="'+id_mainunit+'">'+mainunit_name+'</option>'
                      );
                  });
              }else{
                     $("#mainunit").empty();
              }
              }
          });
      }else{
              $("#mainunit").empty();
      }
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_admin_master.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_admin_master/detail_user.blade.php ENDPATH**/ ?>