<?php $__env->startSection('css'); ?>
<style type="text/css" media="print">
  @page
  {
    size: auto;   /* auto is the initial value */
    margin: 0mm;  /* this affects the margin in the printer settings */
    margin-top: -22vh;
    margin-left: -1.8vh;
  }
  .header-confirm .header-text-confirm {
    padding-top: 8vh;
    line-height: 2vh;
  }
  .header-confirm img {
    margin-top: 3vh;
    height: 2vh;
    width: 2vh;
  }
  .print, .pdf, .logo-header, .nav-right {
    display: none;
  }
  nav, footer {
    display: none;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Berita Acara Serah Terima</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('unit-kerja/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Daftar Pengiriman Barang</li>
        </ol>
      </div>
    </div>
  </div>
</section>
<!-- Content Header -->

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 form-group">
        <a href="<?php echo e(url('petugas/dashboard')); ?>" class="btn btn-primary print mr-2">
          <i class="fas fa-home"></i>
        </a>
        <a href="<?php echo e(url('petugas/cetak-bast/'. $bast->id_order)); ?>" rel="noopener" target="_blank" class="btn btn-danger pdf">
          <i class="fas fa-print"></i>
        </a>
      </div>
      <div class="col-md-12 form-group ">
        <div style="background-color: white;margin-right: 15%;margin-left: 15%;padding:2%;">
          <div class="row">
            <div class="col-md-2">
              <h2 class="page-header">
                <img src="<?php echo e(asset('dist/img/logo-kemenkes-icon.png')); ?>">
              </h2>
            </div>
            <div class="col-md-8 text-center">
              <h2 class="page-header">
                <h5><b>BERITA ACARA SERAH TERIMA BARANG</b></h5>
                <h5><b>KEMENTERIAN KESEHATAN REPUBLIK INDONESIA</b></h5>
                <h6 class="text-uppercase"><b><?php echo e($bast->mainunit_name); ?></b></h6>
                <p><i>Jl. H.R. Rasuna Said Blok X.5 Kav. 4-9, Blok A, 2nd Floor, Jakarta 12950<br>Telp.: (62-21) 5201587, 5201591 Fax. (62-21) 5201591</i></p>
              </h2>
            </div>
            <div class="col-md-2">
              <h2 class="page-header">
                <img src="<?php echo e(asset('dist/img/logo-germas.png')); ?>" style="width: 128px; height: 128px;">
              </h2>
            </div>
            <div class="col-md-12">
              <hr style="border-width: medium;border-color: black;">
            </div>
            <div class="col-md-12">
              <p class="m-0">Nomor    : <?php echo e($bast->id_order); ?></p>
              <p class="m-0">Perihal : <?php echo e($bast->order_category); ?> Barang</p>
            </div>
            <div class="col-md-12 mt-4">
              <p class="text-justify">
                Pada hari ini, <?php echo e(\Carbon\Carbon::parse($bast->order_dt)->isoFormat('dddd')); ?>

                Tanggal <?php echo e(\Carbon\Carbon::parse($bast->order_dt)->isoFormat('DD')); ?>

                Bulan   <?php echo e(\Carbon\Carbon::parse($bast->order_dt)->isoFormat('MMMM')); ?>

                Tahun   <?php echo e(\Carbon\Carbon::parse($bast->order_dt)->isoFormat('YYYY')); ?>

                bertempat di Kompleks Perkantoran dan Pergudangan Kementerian Kesehatan RI
                Jl. Percetakan Negara II No.23 Jakarta Pusat, kami yang bertanda tangan dibawah ini:
              </p>
              <p class="m-0 ml-4 text-capitalize">
                Nama    <span style="margin-left: 2vh;">  : Nurhuda </span></p>
              <p class="text-capitalize ml-4">
                Jabatan <span style="margin-left: 1vh;">    : Pengelola Gudang</span></p>
              <p>
                Dalam berita acara ini bertindak untuk dan atas nama Biro Umum Sekretariat Jenderal Pengelola Gudang yang selanjutnya disebut <span class="font-weight-bold"> PIHAK PERTAMA </span>.
              </p>
              <p class="m-0 ml-4 text-capitalize">
                Nama    <span style="margin-left: 2vh;">  : <?php echo e($bast->order_emp_name); ?> </span></p>
              <p class="ml-4 text-capitalize">
                Jabatan <span style="margin-left: 1vh;">    : <?php echo e($bast->order_emp_position); ?></span></p>
              <p>
                Dalam berita acara ini bertindak untuk dan atas nama <span class="font-weight-bold"> <?php echo e($bast->workunit_name.' '.$bast->mainunit_name); ?> </span> selaku pengirim barang yang selanjutnya disebut PIHAK <span class="font-weight-bold"> KEDUA </span>.
              </p>
              <p class="mt-4 m-0">
                Bahwa PIHAK PERTAMA telah menerima/menyerahkan barang dari/kepada PIHAK KEDUA dengan rincian sebagai berikut:
              </p>
            </div>
            <div class="col-12 table-responsive">
              <table class="table table-striped mt-4">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>NUP</th>
                    <th>Nama Barang</th>
                    <th>Merk</th>
                    <th>Jumlah</th>
                    <th>Satuan</th>
                    <th>Kondisi</th>
                    <th>Lokasi Penyimpanan</th>
                  </tr>
                </thead>
                <?php $no = 1;?>
                <tbody>
                  <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($item->in_item_code); ?></td>
                    <td><?php echo e($item->in_item_nup); ?></td>
                    <td><?php echo e($item->in_item_name); ?></td>
                    <td><?php echo e($item->in_item_merk); ?></td>
                    <td><?php echo e($item->total_item); ?></td>
                    <td><?php echo e($item->in_item_unit); ?></td>
                    <td><?php echo e($item->item_condition_name); ?></td>
                    <td><?php echo e($item->id_slot.' / '.$item->id_warehouse); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="col-md-12 form-group mb-4">
              <p class="text-justify mt-4">
                Barang diterima/diserahkan sesuai dengan catatan kondisi yang tertera dalam surat perintah yang merupakan satu kesatuan dari berita acara ini. Demikian Berita Acara Serah Terima Barang ini dibuat sebagai bukti yang sah sebanyak 2 rangkap dan ditandatangani oleh <span class="font-weight-bold">PIHAK PERTAMA</span> dan <span class="font-weight-bold">PIHAK KEDUA</span>.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/create_bast.blade.php ENDPATH**/ ?>