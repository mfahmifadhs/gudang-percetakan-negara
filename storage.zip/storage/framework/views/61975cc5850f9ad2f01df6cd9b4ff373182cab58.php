<?php $__env->startSection('content'); ?>

<!-- Content Header -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Penapisan Barang</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('Petugas/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Penapisan Barang</li>
        </ol>
      </div>
    </div>
  </div>
</section>
<!-- Content Header -->

<?php $__currentLoopData = $warrent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warrent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 form-group">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
        </div>
        <?php elseif($message = Session::get('failed')): ?>
            <div class="alert alert-danger">
                 <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
      </div>
      <div class="col-md-12 form-group">
        <form action="<?php echo e(url('petugas/tambah-barang')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="card card-outline card-primary">
            <div class="card-header">
              <h3 class="card-title font-weight-bold mt-2">Informasi Pengirim </h3>
              <div class="card-tools">
                <button type="button" class="btn btn-default" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <label>Kode Penyimpanan : </label>
                  <div class="input-group mb-3">
                    <input type="text" name="id_order" class="form-control" value="PBM-<?php echo e(\Carbon\Carbon::now()->isoFormat('DMYYhhmmss')); ?>" readonly>
                  </div>
                </div>
                <div class="col-md-6">
                  <label>Petugas Gudang : </label>
                  <div class="input-group mb-3">
                    <select class="form-control" name="adminuser_id" readonly>
                      <option value="<?php echo e(Auth::id()); ?>"><?php echo e(Auth::user()->full_name); ?></option>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <label>Unit Kerja : </label>
                  <div class="input-group mb-3">
                    <select id="select2-workunit" name="id_workunit" class="form-control select2-workunit" required>
                      <option value="">-- Pilih Unit Kerja --</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <label>Unit Utama :  </label>
                  <div class="input-group mb-3">
                    <select class="form-control" id="mainunit" name="mainunit_id" readonly>
                      <option value="">-- Unit Utama --</option>
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <label>Pengirim : </label>
                  <div class="input-group mb-3">
                    <input type="text" name="order_emp_name" class="form-control text-capitalize"
                    placeholder="Nama Petugas Yang Membawa Barang">
                  </div>
                </div>
                <div class="col-md-6">
                  <label>Jabatan : </label>
                  <div class="input-group mb-3">
                    <input type="text" name="order_emp_position" class="form-control text-capitalize"
                    placeholder="Jabatan Petugas Yang Membawa Barang">
                  </div>
                </div>
                <div class="col-md-12">
                  <label>Nomor Kendaraan : </label>
                  <div class="input-group mb-3">
                    <input type="text" name="order_license_vehicle" class="form-control text-uppercase"
                    placeholder="Plat Nomor Kendaraan" onkeypress="return event.charCode != 32">
                  </div>
                </div>
                <div class="col-md-12">
                  <label>Data Barang Pada Surat Perintah: </label>
                  <div class="input-group mb-3">
                  <table class="table table-bordered table-responsive">
                    <thead>
                      <tr>
                        <th style="width: 1%;">No</th>
                        <th style="width: 20%;">Kategori Barang</th>
                        <th style="width: 10%;">Kode Barang</th>
                        <th style="width: 9%;">NUP</th>
                        <th style="width: 20%;">Nama Barang</th>
                        <th style="width: 20%;">Merk/Type Barang</th>
                        <th style="width: 20%;">Jumlah</th>
                      </tr>
                    </thead>
                    <?php $no = 1;?>
                    <tbody>
                      <?php $__currentLoopData = $warrent->entryitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($item->warr_item_category); ?></td>
                        <td><?php echo e($item->warr_item_code); ?></td>
                        <td><?php echo e($item->warr_item_nup); ?></td>
                        <td><?php echo e($item->warr_item_name); ?></td>
                        <td><?php echo e($item->warr_item_type); ?></td>
                        <td><?php echo e($item->warr_item_qty.' '.$item->warr_item_unit); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="card card-outline card-primary">
            <div class="card-header">
              <h3 class="card-title font-weight-bold mt-2">Informasi Barang </h3>
              <div class="card-tools">
                <button type="button" class="btn btn-default" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="row">

              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_petugas.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_petugas/screening_item.blade.php ENDPATH**/ ?>