<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $warrent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warrent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container-xxl py-5">
  <div class="container" style="margin-top: 100px;">
    <?php if($warrent->warr_status == 'diproses'): ?>
    <a class="btn btn-outline-primary py-2 px-3 mb-4 disabled">
      Diproses
    </a>
    <?php elseif($warrent->warr_status == 'belum diproses'): ?>
    <a class="btn btn-outline-danger py-2 px-3 mb-4 disabled">
      Belum Diproses
    </a>
    <?php else: ?>
    <a class="btn btn-success-danger py-2 px-3 mb-4 disabled">
      Sudah Diproses
    </a>
    <?php endif; ?>
    <div class="card">
      <div class="card-header">
        <div class="row text-center mt-3">
          <div class="col-md-3"><img src="<?php echo e(asset('dist-main/img/logo-kemenkes-icon.png')); ?>"></div>
            <div class="col-md-6">
              <h5><b>KEMENTERIAN KESEHATAN REPUBLIK INDONESIA</b></h5>
              <h6 class="text-uppercase"><b><?php echo e($warrent->workunit_name.' '.$warrent->mainunit_name); ?></b></h6>
              <p>Jl. H.R. Rasuna Said Blok X.5 Kav. 4-9, Blok A, 2nd Floor, Jakarta 12950<br>Telp.: (62-21) 5201587, 5201591 Fax. (62-21) 5201591</p>
            </div>
          <div class="col-md-3"><img src="<?php echo e(asset('dist-main/img/logo-germas.png')); ?>"></div>
        </div>
      </div>
        <div class="card-body">
          <div class="row">
            <p class="m-0">Nomor : <span class="text-uppercase"> <?php echo e($warrent->warr_num); ?> </span></p>
            <p class="m-0">Perihal    :  <span class="text-capitalize"> Surat Perintah <?php echo e($warrent->warr_category); ?> Barang </span></p>
          </div>
          <div class="row mt-4 text-capitalize">
            <p>Dengan ini memerintahkan : </p>
            <p>
                Nama <span style="margin-left:17px;">:</span>  <?php echo e($warrent->warr_name); ?> <br>
                Jabatan : <?php echo e($warrent->warr_position); ?>

            </p>
            <p>Untuk mengirimkan dan menyimpan barang berikut ke Kompleks Perkantoran dan Pergudangan Kementerian Kesehatan RI.</p>
        </div>
        <div class="row m-1">
          <table class="table table-bordered">
            <thead>
              <tr>
                <td>No</td>
                <td>Kategori Barang</td>
                <td>Nama Barang</td>
                <td>Mark/Tipe</td>
                <td>Jumlah</td>
                <td>Satuan</td>
              </tr>
            </thead>
            <?php $no=1; ?>
            <tbody>
              <?php $__currentLoopData = $warrent->entryitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($no++); ?></td>
                  <td><?php echo e($item->warr_item_category); ?></td>
                  <td><?php echo e($item->warr_item_name); ?></td>
                  <td><?php echo e($item->warr_item_type); ?></td>
                  <td><?php echo e($item->warr_item_qty); ?></td>
                  <td><?php echo e($item->warr_item_unit); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <div class="card-footer">
          <a href="#" class="btn btn-primary"><i class="fas fa-print"></i> Cetak</a>
          <a href="#" class="btn btn-primary"><i class="fas fa-file-pdf"></i> Download PDF</a>
        </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_main.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_workunit/detail_surat_perintah.blade.php ENDPATH**/ ?>