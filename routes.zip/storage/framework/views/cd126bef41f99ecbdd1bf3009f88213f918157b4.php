<?php $__env->startSection('content'); ?>

<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Master Gudang</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(url('admin-master/dashboard')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Master Gudang</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
          <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
        <?php if($message = Session::get('failed')): ?>
        <div class="alert alert-danger">
          <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
        </div>
        <?php endif; ?>
      </div>
      <div class="col-md-12">
        <div class="row">
          <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 form-group">
            <div class="card card-primary card-outline" style="height: 100%;font-size: 14px;">
              <div class="card-header">
                <h3 class="card-title mt-2 font-weight-bold"><?php echo e($warehouse->warehouse_name); ?></h3>
                <div class="card-tools">
                  <a href="<?php echo e(url('admin-master/gudang/detail/'.$warehouse->id_warehouse)); ?>" class="btn btn-default"
                  title="Cek Gudang">
                    <i class="fas fa-pallet"></i>
                  </a>
                  <a class="btn btn-default" type="button" data-toggle="modal"
                  data-target="#edit-warehouse<?php echo e($warehouse->id_warehouse); ?>" title="Ubah Informasi Gudang">
                    <i class="fas fa-edit"></i>
                  </a>
                </div>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-6 form-group text-center">
                    <img src="https://cdn-icons-png.flaticon.com/512/2271/2271068.png" style="height: 30vh;"
                    class="img-thumbnail">
                  </div>
                  <div class="col-md-6">
                    <div class="row">
                      <div class="col-md-6">
                        <label>Kode</label>
                        <p><?php echo e($warehouse->id_warehouse); ?></p>
                      </div>
                      <div class="col-md-6">
                        <label>Model Penyimpanan</label>
                        <p><?php echo e($warehouse->warehouse_category); ?></p>
                      </div>
                      <div class="col-md-6">
                        <label>Nama Gudang</label>
                        <p><?php echo e($warehouse->warehouse_name); ?></p>
                      </div>
                      <div class="col-md-6">
                        <label>Status</label>
                        <?php if($warehouse->status_id == 1): ?>
                        <p class="text-success font-weight-bold" readonly>Aktif</p>
                        <?php elseif($warehouse->status_id == 2): ?>
                        <p class="text-danger font-weight-bold" readonly>Tidak Aktif</p>
                        <?php endif; ?>
                      </div>
                      <div class="col-md-12">
                        <label>Keterangan</label>
                        <p><?php echo $warehouse->warehouse_description; ?></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Modal -->
          <div class="modal fade" id="edit-warehouse<?php echo e($warehouse->id_warehouse); ?>">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title"><?php echo e($warehouse->warehouse_name); ?></h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body" style="font-size:14px;">
                  <form action="<?php echo e(url('admin-master/gudang/update/'. $warehouse->id_warehouse)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-md-6 form-group">
                        <label>Kode Gudang</label>
                        <input type="text" class="form-control text-uppercase" name="id_warehouse" value="<?php echo e($warehouse->id_warehouse); ?>">
                      </div>
                      <div class="col-md-6 form-group">
                        <label>Model Penyimpanan</label>
                        <select class="form-control" name="warehouse_category">
                          <option value="<?php echo e($warehouse->warehouse_category); ?>"><?php echo e($warehouse->warehouse_category); ?></option>
                          <?php if($warehouse->warehouse_category == 'Racking'): ?>
                          <option value="Palleting">Palleting</option>
                          <option value="Lainya">Lainya</option>
                          <?php elseif($warehouse->warehouse_category == 'Palleting'): ?>
                          <option value="Racking">Racking</option>
                          <option value="Lainya">Lainya</option>
                          <?php elseif($warehouse->warehouse_category == 'Lainya'): ?>
                          <option value="Palleting">Palleting</option>
                          <option value="Racking">Racking</option>
                          <?php endif; ?>
                        </select>
                      </div>
                      <div class="col-md-6 form-group">
                        <label>Nama Gudang</label>
                        <input type="text" class="form-control" name="warehouse_name" value="<?php echo e($warehouse->warehouse_name); ?>">
                      </div>
                      <div class="col-md-6 form-group">
                        <label>Status Gudang</label>
                        <select class="form-control" name="status_id">
                          <option value="<?php echo e($warehouse->status_id); ?>"><?php echo e($warehouse->status_name); ?></option>
                          <?php if($warehouse->status_id == 1): ?>
                          <option value="2">Tidak Aktif</option>
                          <?php else: ?>
                          <option value="1">Aktif</option>
                          <?php endif; ?>
                        </select>
                      </div>
                      <div class="col-md-12 form-group">
                        <textarea class="form-control summernote" name="warehouse_description">
                          <?php echo $warehouse->warehouse_description; ?>

                        </textarea>
                      </div>
                    </div>
                  </div>
                  <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary" onclick="return confirm('Data sudah benar ?')">
                      Ubah Informasi
                    </button>
                  </div>
                </form>
              </div>
              <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
          </div>
          <!-- /.modal -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
  $(function () {
    // Summernote
    $('.summernote').summernote({
      height: 100

    }).on('summernote.change', function(we, contents, $editable) {
      $(this).html(contents);
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_admin_master.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\gudang-percetakan-negara\resources\views/v_admin_master/show_warehouse.blade.php ENDPATH**/ ?>